using System;
using System.Runtime.InteropServices;
using Windows.Graphics.Capture;

namespace CuboAutomatico.Capture;

internal static class GraphicsCaptureItemInterop
{
    private static readonly Guid IID_GraphicsCaptureItem =
        new("79C3F95B-31F7-4EC2-A464-632EF5D30760");

    [ComImport, Guid("3628E81B-3CAC-4C60-B7F4-23CE0E0C3356"),
     InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IGraphicsCaptureItemInterop
    {
        IntPtr CreateForWindow([In] IntPtr window, [In] ref Guid iid);
        IntPtr CreateForMonitor([In] IntPtr monitor, [In] ref Guid iid);
    }

    [DllImport("combase.dll", PreserveSig = false, CharSet = CharSet.Unicode)]
    private static extern void RoGetActivationFactory(
        string activatableClassId,
        [In] ref Guid iid,
        [Out] out IntPtr factory);

    [DllImport("user32.dll")] private static extern IntPtr GetDesktopWindow();
    [DllImport("user32.dll")] private static extern IntPtr MonitorFromWindow(IntPtr hwnd, uint flags);

    public static GraphicsCaptureItem ForPrimaryMonitor()
    {
        var iid = typeof(IGraphicsCaptureItemInterop).GUID;
        RoGetActivationFactory(
            "Windows.Graphics.Capture.GraphicsCaptureItem", ref iid, out IntPtr factoryPtr);
        var factory = (IGraphicsCaptureItemInterop)Marshal.GetObjectForIUnknown(factoryPtr);
        Marshal.Release(factoryPtr);

        var mon = MonitorFromWindow(GetDesktopWindow(), 1);
        var itemIid = IID_GraphicsCaptureItem;
        var itemPtr = factory.CreateForMonitor(mon, ref itemIid);
        try { return (GraphicsCaptureItem)Marshal.GetObjectForIUnknown(itemPtr); }
        finally { Marshal.Release(itemPtr); }
    }
}