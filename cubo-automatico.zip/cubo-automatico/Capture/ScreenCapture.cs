using System;
using System.Threading.Tasks;
using Windows.Graphics.DirectX;
using Windows.Graphics.DirectX.Direct3D11;
using Vortice.Direct3D11;
using Vortice.DXGI;

namespace CuboAutomatico.Capture;

public sealed class ScreenCapture : IDisposable
{
    public ID3D11Texture2D? CapturedTexture { get; private set; }

    public async Task CapturePrimaryAsync(ID3D11Device device, int timeoutMs = 1500)
    {
        var item = GraphicsCaptureItemInterop.ForPrimaryMonitor();
        using var framePool = Direct3D11CaptureFramePool.Create(
            device.As<IDirect3DDevice>()!,
            DirectXPixelFormat.B8G8R8A8UIntNormalized, 2, item.Size);
        using var session = framePool.CreateCaptureSession(item);
        session.IsCursorCaptureEnabled = true;

        var tcs = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
        framePool.FrameArrived += (s, _) => tcs.TrySetResult(true);
        session.StartCapture();

        var done = await Task.WhenAny(tcs.Task, Task.Delay(timeoutMs));
        session.Dispose();
        if (done != tcs.Task) throw new TimeoutException("Capture timeout.");

        using var frame = framePool.TryGetNextFrame()
            ?? throw new InvalidOperationException("No frame.");

        CapturedTexture?.Dispose();
        CapturedTexture = device.CreateTexture2D(new Texture2DDescription
        {
            Width = (uint)item.Size.Width,
            Height = (uint)item.Size.Height,
            MipLevels = 1,
            ArraySize = 1,
            Format = Format.B8G8R8A8_UNorm,
            SampleDescription = new SampleDescription(1, 0),
            Usage = ResourceUsage.Default,
            BindFlags = BindFlags.ShaderResource | BindFlags.RenderTarget,
            CPUAccessFlags = CpuAccessFlags.None,
            MiscFlags = ResourceOptionFlags.None,
        });

        using var src = frame.Surface.As<ID3D11Texture2D>()!;
        using var ctx = device.ImmediateContext;
        ctx.CopyResource(CapturedTexture, src);
        ctx.Flush();
    }

    public void Dispose() { CapturedTexture?.Dispose(); CapturedTexture = null; }
}