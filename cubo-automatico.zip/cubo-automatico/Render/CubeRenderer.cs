using System;
using System.Numerics;
using System.Runtime.InteropServices;
using Vortice.D3DCompiler;
using Vortice.Direct3D;
using Vortice.Direct3D11;
using Vortice.DXGI;
using Vortice.Mathematics;

namespace CuboAutomatico.Render;

[StructLayout(LayoutKind.Sequential)]
public struct FrameCB
{
    public Matrix4x4 MVP;
    public Vector3   LightDir;
    public float     Pad;
}

public sealed class CubeRenderer : IDisposable
{
    private readonly ID3D11Device _dev;
    private readonly ID3D11DeviceContext _ctx;
    private readonly ID3D11VertexShader _vs;
    private readonly ID3D11PixelShader _ps;
    private readonly ID3D11InputLayout _layout;
    private readonly ID3D11Buffer _vb, _ib, _cb;
    private readonly ID3D11SamplerState _samp;
    private readonly ID3D11RasterizerState _raster;
    private readonly ID3D11DepthStencilState _depth;
    private ID3D11ShaderResourceView? _screenSrv;

    private const int VertexCount = 24;
    private const int IndexCount = 36;
    private const int Stride = 32;

    public CubeRenderer(ID3D11Device dev, ID3D11DeviceContext ctx)
    {
        _dev = dev; _ctx = ctx;
        var vsBlob = Compiler.Compile(ShaderSource, "VSMain", "vs_5_0");
        var psBlob = Compiler.Compile(ShaderSource, "PSMain", "ps_5_0");
        _vs = dev.CreateVertexShader(vsBlob.AsSpan());
        _ps = dev.CreatePixelShader(psBlob.AsSpan());

        var elems = new[]
        {
            new InputElementDescription("POSITION", 0, Format.R32G32B32_Float, 0, 0),
            new InputElementDescription("TEXCOORD", 0, Format.R32G32_Float, 12, 0),
            new InputElementDescription("NORMAL", 0, Format.R32G32B32_Float, 20, 0),
        };
        _layout = dev.CreateInputLayout(elems, vsBlob.AsSpan());

        var verts = BuildCube();
        var indices = BuildIndices();
        _vb = dev.CreateBuffer(verts, new BufferDescription(
            (uint)(verts.Length * sizeof(float)), BindFlags.VertexBuffer,
            ResourceUsage.Immutable, CpuAccessFlags.None, ResourceOptionFlags.None, 0));
        _ib = dev.CreateBuffer(indices, new BufferDescription(
            (uint)(indices.Length * sizeof(ushort)), BindFlags.IndexBuffer,
            ResourceUsage.Immutable, CpuAccessFlags.None, ResourceOptionFlags.None, 0));
        _cb = dev.CreateBuffer(new BufferDescription(
            (uint)Marshal.SizeOf<FrameCB>(), BindFlags.ConstantBuffer,
            ResourceUsage.Default, CpuAccessFlags.None, ResourceOptionFlags.None, 0));

        _samp = dev.CreateSamplerState(new SamplerDescription
        {
            Filter = Filter.MinMagMipLinear,
            AddressU = TextureAddressMode.Clamp,
            AddressV = TextureAddressMode.Clamp,
            AddressW = TextureAddressMode.Clamp,
            ComparisonFunc = ComparisonFunction.Never,
            MaxLOD = float.MaxValue,
        });
        _raster = dev.CreateRasterizerState(new RasterizerDescription
        {
            FillMode = FillMode.Solid,
            CullMode = CullMode.Back,
            FrontCounterClockwise = false,
            DepthClipEnable = true,
        });
        _depth = dev.CreateDepthStencilState(new DepthStencilDescription
        {
            DepthEnable = true,
            DepthWriteMask = DepthWriteMask.All,
            DepthFunc = ComparisonFunction.LessEqual,
        });
    }

    public void SetScreenTexture(ID3D11Texture2D tex)
    {
        _screenSrv?.Dispose();
        _screenSrv = _dev.CreateShaderResourceView(tex);
    }

    public void Draw(Matrix4x4 viewProj, float progress)
    {
        float angle = progress * (MathF.PI / 2f);
        var model = Matrix4x4.CreateRotationY(-angle);
        var mvp = model * viewProj;
        var cb = new FrameCB
        {
            MVP = Matrix4x4.Transpose(mvp),
            LightDir = Vector3.Normalize(new Vector3(-0.4f, 0.3f, -1f)),
            Pad = 0f,
        };
        _ctx.UpdateSubresource(cb, _cb);

        _ctx.IASetInputLayout(_layout);
        _ctx.IASetVertexBuffer(0, _vb, Stride, 0);
        _ctx.IASetIndexBuffer(_ib, Format.R16_UInt, 0);
        _ctx.IASetPrimitiveTopology(PrimitiveTopology.TriangleList);
        _ctx.VSSetShader(_vs);
        _ctx.VSSetConstantBuffer(0, _cb);
        _ctx.PSSetShader(_ps);
        _ctx.PSSetConstantBuffer(0, _cb);
        _ctx.PSSetShaderResource(0, _screenSrv);
        _ctx.PSSetSampler(0, _samp);
        _ctx.RSSetState(_raster);
        _ctx.OMSetDepthStencilState(_depth);
        _ctx.DrawIndexed(IndexCount, 0, 0);
    }

    private static float[] BuildCube()
    {
        float[] v = new float[VertexCount * 8];
        SetFace(v, 0, new(-1,-1, 1), new( 1,-1, 1), new( 1, 1, 1), new(-1, 1, 1), new(0,0,-1), true);
        SetFace(v, 1, new( 1,-1, 1), new( 1,-1,-1), new( 1, 1,-1), new( 1, 1, 1), new(1,0,0), false);
        SetFace(v, 2, new( 1,-1,-1), new(-1,-1,-1), new(-1, 1,-1), new( 1, 1,-1), new(0,0,1), false);
        SetFace(v, 3, new(-1,-1,-1), new(-1,-1, 1), new(-1, 1, 1), new(-1, 1,-1), new(-1,0,0), false);
        SetFace(v, 4, new(-1, 1, 1), new( 1, 1, 1), new( 1, 1,-1), new(-1, 1,-1), new(0,1,0), false);
        SetFace(v, 5, new(-1,-1,-1), new( 1,-1,-1), new( 1,-1, 1), new(-1,-1, 1), new(0,-1,0), false);
        return v;
    }

    private static void SetFace(float[] v, int face,
        Vector3 a, Vector3 b, Vector3 c, Vector3 d, Vector3 n, bool texUV)
    {
        int o = face * 32;
        float u0 = 0f, u1 = texUV ? 1f : 0f, v0 = 0f, v1 = texUV ? 1f : 0f;
        Span<float> quad =
        [
            a.X, a.Y, a.Z, u0, v0, n.X, n.Y, n.Z,
            b.X, b.Y, b.Z, u1, v0, n.X, n.Y, n.Z,
            c.X, c.Y, c.Z, u1, v1, n.X, n.Y, n.Z,
            d.X, d.Y, d.Z, u0, v1, n.X, n.Y, n.Z,
        ];
        quad.CopyTo(v.AsSpan(o));
    }

    private static ushort[] BuildIndices()
    {
        ushort[] idx = new ushort[IndexCount];
        for (int f = 0; f < 6; f++)
        {
            int v0 = f * 4, o = f * 6;
            idx[o + 0] = (ushort)v0;
            idx[o + 1] = (ushort)(v0 + 1);
            idx[o + 2] = (ushort)(v0 + 2);
            idx[o + 3] = (ushort)v0;
            idx[o + 4] = (ushort)(v0 + 2);
            idx[o + 5] = (ushort)(v0 + 3);
        }
        return idx;
    }

    public void Dispose()
    {
        _vs.Dispose(); _ps.Dispose(); _layout.Dispose();
        _vb.Dispose(); _ib.Dispose(); _cb.Dispose();
        _samp.Dispose(); _raster.Dispose(); _depth.Dispose();
        _screenSrv?.Dispose();
    }

    private const string ShaderSource = """
        cbuffer CB : register(b0) {
            float4x4 mvp;
            float3   lightDir;
            float    pad0;
        };
        Texture2D    screenTex : register(t0);
        SamplerState samp      : register(s0);
        struct VSIn  { float3 pos : POSITION; float2 uv : TEXCOORD0; float3 nrm : NORMAL; };
        struct PSIn  { float4 pos : SV_POSITION; float2 uv : TEXCOORD0; float3 nrm : NORMAL; };
        PSIn VSMain(VSIn i) {
            PSIn o;
            o.pos = mul(float4(i.pos, 1.0), mvp);
            o.uv  = i.uv;
            o.nrm = i.nrm;
            return o;
        }
        float4 PSMain(PSIn i) : SV_TARGET {
            float3 n = normalize(i.nrm);
            float  d = saturate(dot(n, -normalize(lightDir)));
            float  shade = lerp(0.55, 1.0, d);
            float3 col = screenTex.Sample(samp, i.uv).rgb * shade;
            float3 vig = lerp(0.85, 1.0, 1.0 - length(i.uv - 0.5) * 1.4);
            return float4(col * vig, 1.0);
        }
        """;
}